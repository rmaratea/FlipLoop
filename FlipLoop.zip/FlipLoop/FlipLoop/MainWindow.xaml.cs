using FlipLoop.Audio;
using Microsoft.Win32;
using System;
using System.IO;
using System.Windows;

namespace FlipLoop;

public partial class MainWindow : Window
{
    private AudioBuffer? _buffer;

    public MainWindow()
    {
        InitializeComponent();
    }

    private void Open_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new OpenFileDialog
        {
            Filter = "Audio Files|*.wav;*.mp3"
        };

        if (dlg.ShowDialog() == true)
        {
            LoadAudio(dlg.FileName);
        }
    }

    private void Exit_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }

    private void LoadAudio(string file)
    {
        try
        {
            _buffer = AudioLoader.Load(file);

            FileNameLabel.Text = _buffer.FileName;

            StatusText.Text =
                $"{_buffer.Duration:mm\\:ss\\.fff}    " +
                $"{_buffer.SampleRate} Hz    " +
                $"{_buffer.Channels} ch";

            Waveform.AudioBuffer = _buffer;
            Waveform.InvalidateVisual();

            BpmLabel.Text = "--";
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                ex.Message,
                "Errore caricamento audio",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }

    private void Window_DragEnter(object sender, DragEventArgs e)
    {
        e.Effects = e.Data.GetDataPresent(DataFormats.FileDrop)
            ? DragDropEffects.Copy
            : DragDropEffects.None;

        e.Handled = true;
    }

    private void Window_Drop(object sender, DragEventArgs e)
    {
        if (!e.Data.GetDataPresent(DataFormats.FileDrop))
            return;

        var files = (string[])e.Data.GetData(DataFormats.FileDrop)!;

        if (files.Length == 0)
            return;

        var ext = Path.GetExtension(files[0]).ToLowerInvariant();

        if (ext is ".wav" or ".mp3")
        {
            LoadAudio(files[0]);
        }
    }
}
